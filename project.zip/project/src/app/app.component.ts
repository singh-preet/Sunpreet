import { Component } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/storage';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { AngularFireDatabase } from '@angular/fire/database';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  uploadPercent: Observable<number>;
  downloadURL: Observable<string>;
  buttonDisabled = true;
  loaderStart = false;
  filename = 'File upload';

  constructor(
    private storage: AngularFireStorage,
    public db: AngularFireDatabase
    ) {

    }

  uploadFile(event) {
    const file = event.target.files[0];
    const filePath = event.target.files[0].name;
    this.filename = filePath;
    const fileRef = this.storage.ref(filePath);
    const task = this.storage.upload(filePath, file);
    this.loaderStart = true;

    // observe percentage changes
    this.uploadPercent = task.percentageChanges();
    // get notified when the download URL is available
    task.snapshotChanges().pipe(
        finalize(() => {
         fileRef.getDownloadURL().subscribe((data)=>{
          this.downloadURL = data;
          this.buttonDisabled = false;
          this.loaderStart = false;


         });
        } )
     )
    .subscribe();
  }

addToDataBase(title) {
  const itemsRef = this.db.list('items');
  itemsRef.push({ name: title.value , image : this.downloadURL});
}

  }
